To install this extension first include
LocalisationUpdate/LocalisationUpdate.php in your LocalSettings.php

Then add the required new tables to your database by running
php maintenance/update.php on the command line.

Whenever you want to run an update, run
php extensions/LocalisationUpdate/update.php on the command line.
